const express = require("express");
const session = require("express-session");
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcrypt");
const helmet = require("helmet");
require("dotenv").config();

const app = express();

// Database
const db = new sqlite3.Database("./users.db", (err) => {
  if (err) {
    console.error("Database error:", err.message);
  } else {
    console.log("Connected to SQLite database");
  }
});

// Create users table
db.run(
  `
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
`,
  (err) => {
    if (err) {
      console.error("Table creation error:", err.message);
    } else {
      console.log("Users table ready");
    }
  },
);

// Security
app.use(helmet());

// Read form data
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Session
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false,
      sameSite: "lax",
    },
  }),
);

// Static files
app.use(express.static("public"));
app.use(express.static("views"));

// Home page
app.get("/", (req, res) => {
  res.redirect("/login.html");
});

// Register
app.post("/register", async (req, res) => {
  const { username, email, password, confirmPassword } = req.body;

  if (!username || !email || !password || !confirmPassword) {
    return res.send("All fields are required.");
  }

  if (password !== confirmPassword) {
    return res.send("Passwords do not match.");
  }

  if (password.length < 8) {
    return res.send("Password must be at least 8 characters.");
  }

  try {
    db.get(
      "SELECT id FROM users WHERE email = ?",
      [email],
      async (err, user) => {
        if (err) {
          console.error("Database error:", err.message);
          return res.send("Database error.");
        }

        if (user) {
          return res.send("An account with this email already exists.");
        }

        const passwordHash = await bcrypt.hash(password, 12);

        db.run(
          `INSERT INTO users
                    (username, email, password_hash)
                    VALUES (?, ?, ?)`,
          [username, email, passwordHash],
          function (err) {
            if (err) {
              console.error("Registration error:", err.message);
              return res.send("Registration failed.");
            }

            res.send(`
                            <h2>Registration successful!</h2>
                            <p>Your account has been created.</p>
                            <a href="/login.html">Go to Login</a>
                        `);
          },
        );
      },
    );
  } catch (error) {
    console.error("Error:", error);
    res.send("Something went wrong.");
  }
});

// Start server
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
